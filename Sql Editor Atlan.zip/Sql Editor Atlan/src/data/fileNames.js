const FILE_NAMES = [
  "categories",
  "customers",
  "employee_territories",
  "employees",
  "order_details",
  "orders",
  "products",
  "regions",
  "shippers",
  "suppliers",
  "territories",
];

export default FILE_NAMES;
